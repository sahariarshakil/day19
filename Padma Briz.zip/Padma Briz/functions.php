<?php
wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'bootstrap-css', get_template_directory_uri().'/assets/css/bootstrap.min.css' );
wp_enqueue_script( 'bootstrap-js', get_template_directory_uri().'/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );

add_theme_support('custom-logo');
add_theme_support('title-tag');
add_theme_support('post-thumbnails');
register_sidebar(array(
    'name'=>'Right logo',
    'id'=>'r_logo'
) );
register_nav_menus([
    'TM'=>'primary',
    'FM'=>'footer',
])




?>